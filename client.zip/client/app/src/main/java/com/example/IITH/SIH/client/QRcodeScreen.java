package com.example.IITH.SIH.client;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class QRcodeScreen extends AppCompatActivity {
    private IntentIntegrator scanQR;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_screen);
        scanQR = new IntentIntegrator(this);
        scanQR.initiateScan();


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {


            } else {
                //if qr contains data

                try {
                    JSONObject json = new JSONObject(result.getContents());
                    //json.put("id",  json.getString(("id")));
                    String name = json.getString("id");
                    Toast.makeText(getApplicationContext(),result.getContents(),Toast.LENGTH_SHORT).show();
                   // Log.i("***value of name =",String.valueOf(name.size()));
                    Log.i("item is =",name);

                    new  SendDeviceDetails().execute("http://192.168.137.219:9000/QRdetails", json.toString());

                } catch (JSONException e) {
                    e.printStackTrace();

                    //Toast.makeText(this, "No such Qr code has ever being made by author", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            super.onActivityResult(requestCode,resultCode,data);
        }

    }
    private class SendDeviceDetails extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            String data = "";

            HttpURLConnection httpURLConnection = null;
            try {

                httpURLConnection = (HttpURLConnection) new URL(params[0]).openConnection();
                httpURLConnection.setRequestMethod("POST");

                httpURLConnection.setDoOutput(true);

                DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
                wr.writeBytes("PostData=" + params[1]);
                wr.flush();
                wr.close();

                InputStream in = httpURLConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(in);

                int inputStreamData = inputStreamReader.read();
                while (inputStreamData != -1) {
                    char current = (char) inputStreamData;
                    inputStreamData = inputStreamReader.read();
                    data += current;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
            }

            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.e("TAG", result); // this is expecting a response code to be sent from your server upon receiving the POST data
        }
    }
}
