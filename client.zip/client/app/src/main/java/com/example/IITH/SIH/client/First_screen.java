package com.example.IITH.SIH.client;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import static com.example.IITH.SIH.client.MySqlliteOpenHepler.TABLE_NAME;

public class First_screen extends AppCompatActivity {
    Button b1,b2;
    EditText tv;
    GPSTracker gps = new GPSTracker(this);
    double latitude,logitude;
    String data = "";
    private MySqlliteOpenHepler mysqllite;
    private SQLiteDatabase mDatabase;
    //  TextView one,two;
    String name,block_id;
    int cursorevalue = -100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.QRcode);
        b2=(Button)findViewById(R.id.Verify);
        createDb();
        insertData();
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(First_screen.this,QRcodeScreen.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getAllRecords();
                String uuid = name;
                String blockid= block_id;

                latitude = gps.getLatitude();
                logitude = gps.getLongitude();

                JSONObject json=new JSONObject();
                tv = (EditText)findViewById(R.id.otp);
                String opt = tv.getText().toString();
                try {
                    String  l = "Lat:"+Double.toString(latitude) + ";Log:" + Double.toString(logitude);
                    json.put("block_id", blockid);
                    json.put("uuid", uuid);
                    json.put("otp", opt);
                    json.put("location",  "Lat:"+Double.toString(latitude) + ";Log:" + Double.toString(logitude) );

                    Toast.makeText(getApplicationContext(),blockid,Toast.LENGTH_LONG).show();

                    new SendDeviceDetails().execute("http://10.1.95.85:9000/otp", json.toString());

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private class SendDeviceDetails extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {



            HttpURLConnection httpURLConnection = null;
            try {

                httpURLConnection = (HttpURLConnection) new URL(params[0]).openConnection();
                httpURLConnection.setRequestMethod("POST");

                httpURLConnection.setDoOutput(true);

                DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
                wr.writeBytes("PostData=" + params[1]);
                wr.flush();
                wr.close();

                InputStream in = httpURLConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(in);

                int inputStreamData = inputStreamReader.read();
                while (inputStreamData != -1) {
                    char current = (char) inputStreamData;
                    inputStreamData = inputStreamReader.read();
                    data += current;

                }
                Log.i("#####", data);


            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
            }

            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.e("TAG", result); // this is expecting a response code to be sent from your server upon receiving the POST data
        }
    }

    public void createDb() {
        mysqllite = new MySqlliteOpenHepler(getApplicationContext());
        mDatabase = mysqllite.getReadableDatabase();
        Cursor cursor = mDatabase.rawQuery("select * from PEOPLE ;",null);
    }



    public void getAllRecords() {
        mDatabase = mysqllite.getReadableDatabase();
        Cursor cursor = mDatabase.query(TABLE_NAME,null,null,null,null,null,null);

        cursorevalue = cursor.getCount();

        if (cursor.getCount() > 0) {
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToNext();
                name = cursor.getString(1);
                block_id = cursor.getString(2);
            }
        }
        //Toast.makeText(getApplicationContext(),name + block_id ,Toast.LENGTH_LONG).show();

        cursor.close();
        mDatabase.close();
    }

    private void insertData() {

        int id = 1;
        String table_name = "PEOPLE";
        ContentValues values = new ContentValues();
        values.put("ID",id);
        values.put("FIRST_NAME","123456789000");
        values.put("BLOCK_ID","[0,0,0]");

        if (mDatabase != null) {
            long rowId = mDatabase.insert(table_name,null,values);
            if (rowId != -1) {

                Toast.makeText(First_screen.this,"successfull ",Toast.LENGTH_SHORT).show();
            } else {
               //nothing.
            }


        } else {
            Toast.makeText(First_screen.this,"database not created ",Toast.LENGTH_SHORT).show();
        }

    }

}
