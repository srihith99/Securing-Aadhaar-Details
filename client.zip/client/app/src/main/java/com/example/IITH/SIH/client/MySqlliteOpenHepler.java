package com.example.IITH.SIH.client;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



/**
 * Created by Mahidhar on 13-01-2018.
 */

public class MySqlliteOpenHepler extends SQLiteOpenHelper {

    public static final String database_name="company.db";
    public static final int database_version=1;

/*
private String table_name="employee";
private String column_id="id",column_name="name";

private String database_create_statement="create table"+table_name+"{"+column_id+
        "integer primary key autoincrement, "+column_name+" text not null );";
*/


    public static final String TABLE_NAME = "PEOPLE";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_NAME = "FIRST_NAME";
    public  static  final  String COLUMN_BLOCK = "BLOCK_ID";



    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " ( " + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAME  + " VARCHAR," + COLUMN_BLOCK + " VARCHAR);");

    }



    public MySqlliteOpenHepler(Context context) {
        super(context,database_name,null,database_version);
    }


/*    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

sqLiteDatabase.execSQL(database_create_statement);


    }*/

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase,int i,int i1) {

    }
}